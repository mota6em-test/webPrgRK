Canvas
- rajzolás (egyszeri)
- animáció (folyamatos rajzolás)
- játék (felhasználói események)

Architektúra
- állapottér (csak adat és függvény)
- kirajzolás (mindig mindent újra)

Megvalósítás
- globális adatokkal
- modularizálva

Lépések
1. HTML: canvas, stílus
2. JS előkészületek
3. Rajzolás: `draw()`
    - háttér
    - űrhajó
    - aszteroida
4. Űrhajó: starship object
5. Animáció: gameLoop
6. Űrhajó mozgása: straship update
7. Játék: események
8. Aszteroidák
  - default
  - mozgatás
  - új
  - törlés
  - ütközés
9. Vége + számláló
10. Képek
